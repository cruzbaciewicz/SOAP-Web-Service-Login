﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace SOAPWebServiceLogin
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {
       public string password(string firstName, string lastName, int age)
        {
            char[] first= firstName.ToCharArray();
            char[] last = lastName.ToCharArray();
            char fLastone = last[0];
            char fLasttwo = last[1];
            char[] final1 = new char[] { 'a', 'v' };
            final1[0]  = fLastone;
            final1[1] = fLasttwo;
            string firstTwoLast = new string(final1); // this is a string with the first two letters of the last name

            char Lfirstone = first[firstName.Length - 2];
            char Lfirsttwo = first[firstName.Length - 1];
            char[] final2 = new char[] { 'a', 'v' };
            final2[0] = Lfirstone;
            final2[1] = Lfirsttwo;
            string lastTwoFirst = new string(final2); //this is a string with the last two letters of the first name

            age = age % 5;

            string password = firstTwoLast + lastTwoFirst + age;
            return password;
        }
      public int loginId(int age)
        {
            Random rando = new Random();
            int agey = age * (rando.Next(100, 200));

            return agey;
        }
    }
}
